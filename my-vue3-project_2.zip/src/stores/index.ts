// 仓库
import {createPinia} from 'pinia'
// 创建仓库
let pinia = createPinia()
export default pinia;
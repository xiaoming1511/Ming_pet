<template>
    <div>
        <test></test>
    </div>
</template>

<script setup lang="ts">



</script>

<style scoped></style>
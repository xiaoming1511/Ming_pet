export default{
  login:{
    userName:'userName',
    password:'passWord',
    login: "Login",
    register: "Register",
  }
}
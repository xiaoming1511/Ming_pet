<template>
    <div class="flex pt7">
        <test></test>
        <OrderChart></OrderChart>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
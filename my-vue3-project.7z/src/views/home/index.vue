<template>
    <div class="w-screen relative h-screen box-border">
        <transition name="slide">
            <n-layout has-sider class="flex-c">
                <Menu class="relative fixed-menu"></Menu>
                <n-flex class="w-screen hmain" :style="{ marginLeft: sidebarStore.isSidebarExpanded ? `64px` : '210px' }">
                    <Navigator class="navigation-bar"
                        :style="{ marginLeft: sidebarStore.isSidebarExpanded ? `64px` : '210px' }"></Navigator>
                    <router-view class="bg-gray-100 pt-5 mt-16"></router-view>
                </n-flex>
            </n-layout>
        </transition>
    </div>
</template>

<script setup lang="ts">
import { useSidebarStore } from '@/stores/modules/sidebar';

const sidebarStore = useSidebarStore();

</script>

<style scoped>
@import '@/style/login.css';

.hmain {
    display: block !important;
    transition: margin-left 0.4s ease;
}

:deep(.n-card__content) {
    padding: 1.25rem !important;
}

:deep(.box) {
    display: flex !important;
    flex-wrap: nowrap !important;
}

.fixed-menu {
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    z-index: 1001;
}

.navigation-bar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1002;
    transition: margin-left 0.4s ease;
}
</style>
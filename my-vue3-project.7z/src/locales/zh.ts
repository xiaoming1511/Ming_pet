export default {
  login: {
    userName: "用户名",
    password: "密码",
    login:"登录",
    register: "注册",
  },
};
